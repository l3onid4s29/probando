﻿![](Aspose.Words.277945fa-b102-4a36-ae3d-74f8ab004b9a.001.png)


**DEPARTAMENTO DE CIENCIAS DE LA COMPUTACIÓN**

**LABORATORIO #6**
|<p>**CARRERA:**</p><p>Ingeniería Electrónica</p>|<p>**GUÍA**</p><p>No. 05</p>|<p>**TIEMPO ESTIMADO:**</p><p>1h y 20 min.</p>|
| :- | :- | :- |
|<p>**ASIGNATURA:**</p><p>Programacion Orientada a Objetos </p>|**FECHA DE ELABORACION:**  02/07/2021      <br>**SEMESTRE**: Mayo  – Septiembre 2021|
|<p>**TÍTULO:**</p><p>Bases de Datos</p>|<p>**DOCENTE: Ing. César Osorio**</p><p>**Integrantes: Christian Ponce, Josue Pillajo, Eliana Apunte, Leonidas Rosales**</p>|

**OBJETIVO**

p.e. Generacón de consultas y acceso a una base de Datos

**INSTRUCCIONES**

**p.e.**

1) Utilice como material principal, aquel indicado en clase por el docente.
1) Utilice información consultada en Internet y conocimiento adquirido en clase.

**ACTIVIDADES**

1. **Ubicación de recursos**

**p.e.**

1) Formar grupos de máximo 4 personas por computador
1) Utilizar Netbeans












1. **Planteamiento del problema**

**p.e. Ejercicio** 

Con el script dado en clase para la creación de las diversas tablas de una base de datos; genere las instrucciones necesarias para extraer datos según los siguientes requerimientos:


- Consulta para extraer el nombre de los clientes con el porcentaje de descuento obtenido en la compra y cual fue el vendedor que vendió o atendió el pedido.

`             `![](Aspose.Words.277945fa-b102-4a36-ae3d-74f8ab004b9a.002.png)






- Consulta para extraer los productos con el nombre de proveedor y su contacto.

![](Aspose.Words.277945fa-b102-4a36-ae3d-74f8ab004b9a.003.png)












- Consulta para extraer de la tabla ordenes los clientes cuyo nombre empiecen con la letra s.

![](Aspose.Words.277945fa-b102-4a36-ae3d-74f8ab004b9a.004.png)

- Consulta para mostrar los productos con sus categorías ordenado por categoría.

![](Aspose.Words.277945fa-b102-4a36-ae3d-74f8ab004b9a.005.png)

**Marco Teórico:**

¿Qué es una base de datos SQL?

Las bases de datos SQL son las más utilizadas en la actualidad. Consisten en bases de datos relacionales que utilizan el llamado lenguaje SQL, es decir, el lenguaje de consulta estructurado o, como se conoce en inglés, Structured Query Language.

Una base de datos SQL está formada por tablas con filas y columnas. En las filas figuran los diferentes registros de la tabla, mientras que las columnas corresponden a los campos. Las bases que utilizan el lenguaje SQL son consideradas como el estándar según el American National Standards Institute (ANSI), esto es, la autoridad americana oficial de estándares.

Pero, ¿por qué se caracteriza el SQL? Lo vemos en el siguiente punto.

Características de SQL:

Ya hemos mencionado que el lenguaje SQL es el que permite la creación de este tipo de tablas relacionales. Dicho lenguaje tienes las siguientes características:

Se trata de un lenguaje de definición de datos que contienen comando que permite establecer, modificar o borrar esquemas de relación.

Es un lenguaje interactivo que permite realizar consultas gracias al álgebra y el cálculo relacional.

Permite establecer restricciones de integridad a la información que se almacena en una base de datos.

Facilita la creación de bases de datos mediante tablas, las cuáles a su vez están formadas por registros (filas) y campos (columnas).

El lenguaje SQL es compatible con otros lenguajes de programación como Java, C++ o PHP.

Se pueden incluir, a través de comandos, los derechos de acceso a relaciones y vistas de las bases de datos..

Ventajas de las bases de datos SQL

Las bases de datos SQL ofrecen diversas ventajas que las han convertido en las más utilizadas a la hora de almacenar información.

Garantizan solvencia y consistencia de la hora de almacenar y consultar los datos.

Favorecen la integridad de la información que se alberga en ellas.

Se crean en base a un lenguaje estandarizado como es el SQL.

Los datos se pueden consultar de forma clara y sencilla.

Son muy versátiles y flexibles.

Por su parte, algunos de los contras a los que se enfrentan las bases de datos relacionales es la necesidad de conocer el lenguaje SQL y sus limitaciones a la hora de trabajar con grandes volúmenes de datos.

Ejemplos de bases de datos hechas en SQL

¿Quieres ver algún ejemplo de base de datos en SQL? Puedes hacerlo en este enlace de la página oficial de Microsoft.

Bases de datos basadas en SQL

Los términos base de datos y SQL están íntimamente unidos. De hecho, existen diversas herramientas que permiten crear bases de datos relacionales basadas en este lenguaje. A continuación te mostramos algunas de las más conocidas.

MySQL

MySQL es el principal gestor de bases de datos en SQL. Se diferencia de otras como Oracle y SQL Server en que es una herramienta open source o de código abierto. Otra de sus diferencias es que una base de datos MySQL está diseñada para satisfacer las necesidades de todo tipo de usuarios, mientras que Oracle o SQL Server están más orientadas al ámbito empresarial.

Oracle

Oracle fue la empresa que comercializó el primer sistema de gestión de bases de datos relacionales, aunque había sido diseñado por IBM. En la actualidad, el gestor de bases de datos SQL de Oracle consiste en un sistema cerrado, y es una de las herramientas más potentes del mercado, destinada principalmente a medianas o grandes empresas.

Microsoft Access

Microsoft Access es una herramienta de Microsoft para la creación de bases de datos SQL. Si quieres saber más sobre este programa te recomendamos leer nuestro artículo sobre bases de datos en Access.

Otras herramientas para la gestión de bases de datos relacionales son SQL Server o SQlite.



**Conclusión:** 

La base de datos es una colección de información organizada que puede seleccionar de forma rápida y eficiente los fragmentos de los datos que se necesite o se esté desarrollando.

**Recomendación:**

Realizar más ejercicios en clase para poder aclarecer nuestras dudas e inquietudes y así poder desarrollar nuestro conocimiento en la materia y así emplearlo con claridad en nuestra respectiva carrera.




**Bibliografía:**

https://ayudaleyprotecciondatos.es/bases-de-datos/sql/






\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_		\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

`      `DOCENTE RESPONSABLE			         COORDINADOR DE ÁREA

`          `Ing. César O. Osorio A		   		Ing. Silvia Arévalo
